/* =====================================================================
 * ShardCore - everything in one file.
 *
 * This Java file contains all the code (economy, /sell, auction house,
 * /rtp, homes, /tpa and teams). Minecraft also requires a plugin.yml, and
 * Maven needs a pom.xml to build it. Their full contents are below, so
 * this one file has everything you need.
 *
 * PROJECT LAYOUT
 *   pom.xml
 *   src/main/java/dev/shardcore/ShardCore.java   <- this file
 *   src/main/resources/plugin.yml
 *
 * BUILD:  install JDK 21 + Maven, then run  mvn package
 *         and put target/ShardCore.jar in your server's plugins folder.
 *
 * ---------------------------------------------------------------------
 * plugin.yml
 * ---------------------------------------------------------------------
 * name: ShardCore
 * version: '${project.version}'
 * main: dev.shardcore.ShardCore
 * api-version: '1.21'
 * description: Shard economy and sell system
 * commands:
 *   bal:
 *     description: Check your shard balance
 *     aliases: [balance, shards]
 *     usage: /bal [player]
 *   pay:
 *     description: Send shards to a player
 *     usage: /pay <player> <amount>
 *   sell:
 *     description: Sell items for shards
 *     usage: /sell [hand|all|gui]
 *   ah:
 *     description: Open the auction house
 *     aliases: [auction, auctionhouse]
 *     usage: /ah [sell <price>|mine|claim]
 *   rtp:
 *     description: Teleport to a random location
 *     aliases: [randomtp, wild]
 *     usage: /rtp
 *   sethome:
 *     description: Set a home at your location
 *     usage: /sethome [name]
 *   home:
 *     description: Teleport to a home
 *     usage: /home [name]
 *   delhome:
 *     description: Delete a home
 *     usage: /delhome <name>
 *   homes:
 *     description: List your homes
 *     usage: /homes
 *   tpa:
 *     description: Request to teleport to a player
 *     usage: /tpa <player>
 *   tpahere:
 *     description: Request a player to teleport to you
 *     usage: /tpahere <player>
 *   tpaccept:
 *     description: Accept a teleport request
 *     usage: /tpaccept
 *   tpdeny:
 *     description: Deny a teleport request
 *     usage: /tpdeny
 *   tpcancel:
 *     description: Cancel your outgoing teleport request
 *     usage: /tpcancel
 *   team:
 *     description: Create and manage teams
 *     aliases: [t]
 *     usage: /team help
 *   tc:
 *     description: Team chat
 *     aliases: [teamchat]
 *     usage: /tc [message]
 *   eco:
 *     description: Admin economy command
 *     usage: /eco <give|take|set> <player> <amount>
 *     permission: shardcore.admin
 * permissions:
 *   shardcore.admin:
 *     default: op
 *
 * ---------------------------------------------------------------------
 * pom.xml
 * ---------------------------------------------------------------------
 * <?xml version="1.0" encoding="UTF-8"?>
 * <project xmlns="http://maven.apache.org/POM/4.0.0"
 *          xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
 *          xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
 *     <modelVersion>4.0.0</modelVersion>
 *
 *     <groupId>dev.shardcore</groupId>
 *     <artifactId>ShardCore</artifactId>
 *     <version>1.0.0</version>
 *     <packaging>jar</packaging>
 *
 *     <properties>
 *         <maven.compiler.source>21</maven.compiler.source>
 *         <maven.compiler.target>21</maven.compiler.target>
 *         <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
 *     </properties>
 *
 *     <repositories>
 *         <repository>
 *             <id>papermc</id>
 *             <url>https://repo.papermc.io/repository/maven-public/</url>
 *         </repository>
 *     </repositories>
 *
 *     <dependencies>
 *         <dependency>
 *             <groupId>io.papermc.paper</groupId>
 *             <artifactId>paper-api</artifactId>
 *             <version>1.21.1-R0.1-SNAPSHOT</version>
 *             <scope>provided</scope>
 *         </dependency>
 *     </dependencies>
 *
 *     <build>
 *         <finalName>ShardCore</finalName>
 *         <resources>
 *             <resource>
 *                 <directory>src/main/resources</directory>
 *                 <filtering>true</filtering>
 *             </resource>
 *         </resources>
 *     </build>
 * </project>
 * ===================================================================== */

package dev.shardcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.entity.Projectile;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * ShardCore - shard economy, /sell and auction house in a single file.
 */
public class ShardCore extends JavaPlugin implements CommandExecutor, Listener {

    private static final String PREFIX = "§b[Shards] §f";
    private Economy economy;
    private AuctionHouse auctionHouse;
    private Homes homes;
    private Teams teams;
    private final Map<UUID, Long> rtpCooldowns = new HashMap<>();
    private final Set<UUID> rtpBusy = new HashSet<>();

    // =====================================================================
    //  Plugin lifecycle
    // =====================================================================

    @Override
    public void onEnable() {
        setupConfigDefaults();
        economy = new Economy(this);

        for (String cmd : new String[]{"bal", "pay", "sell", "eco", "rtp"}) {
            getCommand(cmd).setExecutor(this);
        }
        getServer().getPluginManager().registerEvents(this, this);

        auctionHouse = new AuctionHouse(this, economy);
        getCommand("ah").setExecutor(auctionHouse);
        getServer().getPluginManager().registerEvents(auctionHouse, this);

        homes = new Homes(this);
        for (String cmd : new String[]{"sethome", "home", "delhome", "homes"}) {
            getCommand(cmd).setExecutor(homes);
            getCommand(cmd).setTabCompleter(homes);
        }

        Tpa tpa = new Tpa(this);
        for (String cmd : new String[]{"tpa", "tpahere", "tpaccept", "tpdeny", "tpcancel"}) {
            getCommand(cmd).setExecutor(tpa);
            getCommand(cmd).setTabCompleter(tpa);
        }

        teams = new Teams(this);
        for (String cmd : new String[]{"team", "tc"}) {
            getCommand(cmd).setExecutor(teams);
            getCommand(cmd).setTabCompleter(teams);
        }
        getServer().getPluginManager().registerEvents(teams, this);

        // Autosave every 5 minutes (main thread, so data isn't modified mid-save)
        getServer().getScheduler().runTaskTimer(this, () -> {
            economy.save();
            auctionHouse.save();
            homes.save();
            teams.save();
        }, 6000L, 6000L);

        getLogger().info("ShardCore enabled.");
    }

    @Override
    public void onDisable() {
        if (economy != null) economy.save();
        if (auctionHouse != null) auctionHouse.save();
        if (homes != null) homes.save();
        if (teams != null) teams.save();
    }

    /** Defaults live in code, so no separate config.yml is needed. Edit plugins/ShardCore/config.yml to change them. */
    private void setupConfigDefaults() {
        getConfig().addDefault("starting-balance", 0);
        getConfig().addDefault("auction.max-listings", 5);
        getConfig().addDefault("auction.expire-hours", 48);
        getConfig().addDefault("auction.tax-percent", 5);
        getConfig().addDefault("auction.max-price", 1_000_000_000L);

        getConfig().addDefault("homes.max", 3);
        getConfig().addDefault("tpa.expire-seconds", 60);
        getConfig().addDefault("teams.max-members", 5);
        getConfig().addDefault("teams.invite-expire-seconds", 60);
        getConfig().addDefault("rtp.min-distance", 500);
        getConfig().addDefault("rtp.max-distance", 5000);
        getConfig().addDefault("rtp.cooldown-seconds", 30);
        getConfig().addDefault("rtp.max-attempts", 15);

        Map<String, Integer> prices = new LinkedHashMap<>();
        prices.put("COBBLESTONE", 1);
        prices.put("STONE", 1);
        prices.put("DIRT", 1);
        prices.put("OAK_LOG", 3);
        prices.put("COAL", 8);
        prices.put("IRON_INGOT", 15);
        prices.put("GOLD_INGOT", 25);
        prices.put("REDSTONE", 5);
        prices.put("LAPIS_LAZULI", 6);
        prices.put("DIAMOND", 100);
        prices.put("EMERALD", 80);
        prices.put("NETHERITE_INGOT", 1500);
        prices.put("WHEAT", 3);
        prices.put("CARROT", 3);
        prices.put("POTATO", 3);
        prices.put("BONE", 4);
        prices.put("GUNPOWDER", 10);
        prices.put("ENDER_PEARL", 30);
        prices.put("BLAZE_ROD", 20);
        prices.forEach((k, v) -> getConfig().addDefault("prices." + k, v));

        getConfig().options().copyDefaults(true);
        saveConfig();
    }

    // =====================================================================
    //  Economy, /bal, /pay, /eco, /sell
    // =====================================================================

    /** Marker holder so we can recognize our sell GUI. */
    private static class SellHolder implements InventoryHolder {
        private Inventory inv;
        @Override
        public @NotNull Inventory getInventory() { return inv; }
    }

    private void msg(CommandSender s, String text) {
        s.sendMessage(PREFIX + text);
    }

    private long priceOf(Material m) {
        return getConfig().getLong("prices." + m.name(), 0);
    }

    private Long parseAmount(CommandSender s, String raw) {
        try {
            long v = Long.parseLong(raw);
            if (v <= 0) throw new NumberFormatException();
            return v;
        } catch (NumberFormatException e) {
            msg(s, "§cEnter a whole number greater than 0.");
            return null;
        }
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd,
                             @NotNull String label, @NotNull String[] args) {
        switch (cmd.getName().toLowerCase()) {
            case "bal" -> handleBal(sender, args);
            case "pay" -> handlePay(sender, args);
            case "sell" -> handleSell(sender, args);
            case "eco" -> handleEco(sender, args);
            case "rtp" -> handleRtp(sender);
        }
        return true;
    }

    private void handleBal(CommandSender sender, String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player p)) { msg(sender, "Specify a player."); return; }
            msg(p, "You have §e" + Economy.format(economy.get(p.getUniqueId())) + " shards§f.");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) { msg(sender, "§cThat player is not online."); return; }
        msg(sender, target.getName() + " has §e" + Economy.format(economy.get(target.getUniqueId())) + " shards§f.");
    }

    private void handlePay(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) { msg(sender, "Players only."); return; }
        if (args.length < 2) { msg(p, "§cUsage: /pay <player> <amount>"); return; }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) { msg(p, "§cThat player is not online."); return; }
        if (target.equals(p)) { msg(p, "§cYou can't pay yourself."); return; }
        Long amount = parseAmount(p, args[1]);
        if (amount == null) return;
        if (!economy.take(p.getUniqueId(), amount)) { msg(p, "§cYou don't have enough shards."); return; }
        economy.add(target.getUniqueId(), amount);
        msg(p, "Sent §e" + Economy.format(amount) + " shards §fto " + target.getName() + ".");
        msg(target, p.getName() + " sent you §e" + Economy.format(amount) + " shards§f.");
    }

    private void handleEco(CommandSender sender, String[] args) {
        if (!sender.hasPermission("shardcore.admin")) { msg(sender, "§cNo permission."); return; }
        if (args.length < 3) { msg(sender, "§cUsage: /eco <give|take|set> <player> <amount>"); return; }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) { msg(sender, "§cThat player is not online."); return; }
        long amount;
        try {
            amount = Long.parseLong(args[2]);
            if (amount < 0) throw new NumberFormatException();
        } catch (NumberFormatException e) { msg(sender, "§cInvalid amount."); return; }

        switch (args[0].toLowerCase()) {
            case "give" -> economy.add(target.getUniqueId(), amount);
            case "take" -> economy.set(target.getUniqueId(), economy.get(target.getUniqueId()) - amount);
            case "set" -> economy.set(target.getUniqueId(), amount);
            default -> { msg(sender, "§cUsage: /eco <give|take|set> <player> <amount>"); return; }
        }
        msg(sender, target.getName() + " now has §e" + Economy.format(economy.get(target.getUniqueId())) + " shards§f.");
    }

    private void handleSell(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) { msg(sender, "Players only."); return; }
        String mode = args.length == 0 ? "hand" : args[0].toLowerCase();

        switch (mode) {
            case "hand" -> {
                ItemStack item = p.getInventory().getItemInMainHand();
                long price = priceOf(item.getType());
                if (item.getType() == Material.AIR || price <= 0) {
                    msg(p, "§cThat item can't be sold.");
                    return;
                }
                long total = price * item.getAmount();
                p.getInventory().setItemInMainHand(null);
                economy.add(p.getUniqueId(), total);
                msg(p, "Sold for §e" + Economy.format(total) + " shards§f.");
            }
            case "all" -> {
                long total = 0;
                ItemStack[] contents = p.getInventory().getStorageContents();
                for (int i = 0; i < contents.length; i++) {
                    ItemStack item = contents[i];
                    if (item == null) continue;
                    long price = priceOf(item.getType());
                    if (price <= 0) continue;
                    total += price * item.getAmount();
                    contents[i] = null;
                }
                if (total == 0) { msg(p, "§cYou have nothing sellable."); return; }
                p.getInventory().setStorageContents(contents);
                economy.add(p.getUniqueId(), total);
                msg(p, "Sold everything for §e" + Economy.format(total) + " shards§f.");
            }
            case "gui" -> {
                SellHolder holder = new SellHolder();
                Inventory inv = Bukkit.createInventory(holder, 54, Component.text("Sell Items"));
                holder.inv = inv;
                p.openInventory(inv);
            }
            default -> msg(p, "§cUsage: /sell [hand|all|gui]");
        }
    }

    @EventHandler
    public void onSellGuiClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof SellHolder)) return;
        if (!(e.getPlayer() instanceof Player p)) return;

        long total = 0;
        for (ItemStack item : e.getInventory().getContents()) {
            if (item == null) continue;
            long price = priceOf(item.getType());
            if (price > 0) {
                total += price * item.getAmount();
            } else {
                // Give back anything that can't be sold
                Map<Integer, ItemStack> leftover = p.getInventory().addItem(item);
                leftover.values().forEach(i -> p.getWorld().dropItemNaturally(p.getLocation(), i));
            }
        }
        e.getInventory().clear();
        if (total > 0) {
            economy.add(p.getUniqueId(), total);
            msg(p, "Sold for §e" + Economy.format(total) + " shards§f.");
        }
    }

    // =====================================================================
    //  /rtp - random teleport
    // =====================================================================

    private void handleRtp(CommandSender sender) {
        if (!(sender instanceof Player p)) { msg(sender, "Players only."); return; }

        World world = p.getWorld();
        if (world.getEnvironment() != World.Environment.NORMAL) {
            msg(p, "§c/rtp only works in the overworld.");
            return;
        }
        if (rtpBusy.contains(p.getUniqueId())) {
            msg(p, "§cYou're already being teleported.");
            return;
        }

        if (!p.hasPermission("shardcore.rtp.bypass")) {
            long cooldownMs = getConfig().getLong("rtp.cooldown-seconds", 30) * 1000L;
            long last = rtpCooldowns.getOrDefault(p.getUniqueId(), 0L);
            long left = cooldownMs - (System.currentTimeMillis() - last);
            if (left > 0) {
                msg(p, "§cWait §e" + ((left + 999) / 1000) + "s §cbefore using /rtp again.");
                return;
            }
        }

        rtpBusy.add(p.getUniqueId());
        msg(p, "Searching for a safe spot...");
        tryRtp(p, world, getConfig().getInt("rtp.max-attempts", 15));
    }

    private void tryRtp(Player p, World world, int attemptsLeft) {
        if (!p.isOnline()) { rtpBusy.remove(p.getUniqueId()); return; }
        if (attemptsLeft <= 0) {
            rtpBusy.remove(p.getUniqueId());
            msg(p, "§cCouldn't find a safe spot. Try again.");
            return;
        }

        int min = getConfig().getInt("rtp.min-distance", 500);
        int max = Math.max(min + 1, getConfig().getInt("rtp.max-distance", 5000));
        ThreadLocalRandom rng = ThreadLocalRandom.current();

        double angle = rng.nextDouble() * Math.PI * 2;
        double dist = min + rng.nextDouble() * (max - min);
        Location center = world.getSpawnLocation();
        double x = center.getBlockX() + Math.cos(angle) * dist;
        double z = center.getBlockZ() + Math.sin(angle) * dist;

        // Stay inside the world border
        double half = world.getWorldBorder().getSize() / 2.0 - 16;
        Location bc = world.getWorldBorder().getCenter();
        x = Math.max(bc.getX() - half, Math.min(bc.getX() + half, x));
        z = Math.max(bc.getZ() - half, Math.min(bc.getZ() + half, z));

        final int bx = (int) Math.floor(x);
        final int bz = (int) Math.floor(z);

        world.getChunkAtAsync(bx >> 4, bz >> 4).thenAccept(chunk ->
                Bukkit.getScheduler().runTask(this, () -> {
                    int y = world.getHighestBlockYAt(bx, bz);
                    if (!isSafeRtpSpot(world, bx, y, bz)) {
                        tryRtp(p, world, attemptsLeft - 1);
                        return;
                    }
                    Location dest = new Location(world, bx + 0.5, y + 1, bz + 0.5,
                            p.getLocation().getYaw(), p.getLocation().getPitch());
                    p.teleportAsync(dest).thenAccept(ok -> {
                        rtpBusy.remove(p.getUniqueId());
                        if (ok) {
                            rtpCooldowns.put(p.getUniqueId(), System.currentTimeMillis());
                            msg(p, "Teleported to §e" + bx + ", " + (y + 1) + ", " + bz + "§f.");
                        } else {
                            msg(p, "§cTeleport failed. Try again.");
                        }
                    });
                }));
    }

    private boolean isSafeRtpSpot(World world, int x, int y, int z) {
        if (y <= world.getMinHeight() || y >= world.getMaxHeight() - 3) return false;

        Block ground = world.getBlockAt(x, y, z);
        Material type = ground.getType();
        if (ground.isLiquid() || type.isAir()) return false;
        if (Tag.LEAVES.isTagged(type)) return false;
        switch (type) {
            case CACTUS, MAGMA_BLOCK, FIRE, SOUL_FIRE, CAMPFIRE, SOUL_CAMPFIRE,
                 SWEET_BERRY_BUSH, POWDER_SNOW, WITHER_ROSE, POINTED_DRIPSTONE -> { return false; }
            default -> { }
        }

        // Two blocks of free, harmless space above for the player's body
        Block feet = world.getBlockAt(x, y + 1, z);
        Block head = world.getBlockAt(x, y + 2, z);
        return feet.isPassable() && head.isPassable() && !feet.isLiquid() && !head.isLiquid();
    }

    // =====================================================================
    //  Economy storage
    // =====================================================================

    public static class Economy {

        private final JavaPlugin plugin;
        private final File file;
        private final Map<UUID, Long> balances = new HashMap<>();

        public Economy(JavaPlugin plugin) {
            this.plugin = plugin;
            this.file = new File(plugin.getDataFolder(), "balances.yml");
            load();
        }

        private void load() {
            if (!file.exists()) return;
            YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
            for (String key : yml.getKeys(false)) {
                try {
                    balances.put(UUID.fromString(key), yml.getLong(key));
                } catch (IllegalArgumentException ignored) {
                }
            }
        }

        public void save() {
            YamlConfiguration yml = new YamlConfiguration();
            for (Map.Entry<UUID, Long> e : balances.entrySet()) {
                yml.set(e.getKey().toString(), e.getValue());
            }
            try {
                plugin.getDataFolder().mkdirs();
                yml.save(file);
            } catch (IOException ex) {
                plugin.getLogger().severe("Could not save balances: " + ex.getMessage());
            }
        }

        public long get(UUID id) {
            return balances.getOrDefault(id, plugin.getConfig().getLong("starting-balance", 0));
        }

        public void set(UUID id, long amount) {
            balances.put(id, Math.max(0, amount));
        }

        public void add(UUID id, long amount) {
            set(id, get(id) + amount);
        }

        /** Returns true if the player had enough and the shards were removed. */
        public boolean take(UUID id, long amount) {
            long bal = get(id);
            if (bal < amount) return false;
            set(id, bal - amount);
            return true;
        }

        public static String format(long amount) {
            return String.format("%,d", amount);
        }
    }

    // =====================================================================
    //  Auction house
    // =====================================================================

    public static class AuctionHouse implements CommandExecutor, Listener {

        private static final String AH_PREFIX = "§6[AH] §f";
        private static final int PAGE_SIZE = 45;
        private static final int SLOT_PREV = 45, SLOT_MODE = 47, SLOT_INFO = 49, SLOT_CLAIM = 51, SLOT_NEXT = 53;

        private static class Listing {
            String id;
            UUID seller;
            String sellerName;
            ItemStack item;
            long price;
            long created;
        }

        private static class AHHolder implements InventoryHolder {
            Inventory inv;
            int page;
            boolean mine;
            final List<Listing> shown = new ArrayList<>();
            @Override
            public @NotNull Inventory getInventory() { return inv; }
        }

        private final ShardCore plugin;
        private final Economy economy;
        private final File file;
        private final Map<String, Listing> listings = new LinkedHashMap<>();
        private final Map<UUID, List<ItemStack>> claims = new HashMap<>();

        public AuctionHouse(ShardCore plugin, Economy economy) {
            this.plugin = plugin;
            this.economy = economy;
            this.file = new File(plugin.getDataFolder(), "auctions.yml");
            load();
            // Check for expired listings every minute (main thread)
            Bukkit.getScheduler().runTaskTimer(plugin, this::expireListings, 1200L, 1200L);
        }

        // ---------- Storage ----------

        private void load() {
            if (!file.exists()) return;
            YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);

            ConfigurationSection ls = yml.getConfigurationSection("listings");
            if (ls != null) {
                for (String id : ls.getKeys(false)) {
                    ConfigurationSection s = ls.getConfigurationSection(id);
                    if (s == null) continue;
                    ItemStack item = s.getItemStack("item");
                    String seller = s.getString("seller");
                    if (item == null || seller == null) continue;
                    Listing l = new Listing();
                    l.id = id;
                    l.seller = UUID.fromString(seller);
                    l.sellerName = s.getString("name", "Unknown");
                    l.item = item;
                    l.price = s.getLong("price");
                    l.created = s.getLong("created");
                    listings.put(id, l);
                }
            }

            ConfigurationSection cs = yml.getConfigurationSection("claims");
            if (cs != null) {
                for (String uuid : cs.getKeys(false)) {
                    List<ItemStack> items = new ArrayList<>();
                    for (Object o : cs.getList(uuid, List.of())) {
                        if (o instanceof ItemStack is) items.add(is);
                    }
                    if (!items.isEmpty()) claims.put(UUID.fromString(uuid), items);
                }
            }
        }

        public void save() {
            YamlConfiguration yml = new YamlConfiguration();
            for (Listing l : listings.values()) {
                String p = "listings." + l.id + ".";
                yml.set(p + "seller", l.seller.toString());
                yml.set(p + "name", l.sellerName);
                yml.set(p + "item", l.item);
                yml.set(p + "price", l.price);
                yml.set(p + "created", l.created);
            }
            for (Map.Entry<UUID, List<ItemStack>> e : claims.entrySet()) {
                yml.set("claims." + e.getKey(), e.getValue());
            }
            try {
                plugin.getDataFolder().mkdirs();
                yml.save(file);
            } catch (IOException ex) {
                plugin.getLogger().severe("Could not save auctions: " + ex.getMessage());
            }
        }

        // ---------- Helpers ----------

        private void msg(CommandSender s, String text) {
            s.sendMessage(AH_PREFIX + text);
        }

        private long expireMillis() {
            return plugin.getConfig().getLong("auction.expire-hours", 48) * 3_600_000L;
        }

        private void addClaim(UUID id, ItemStack item) {
            claims.computeIfAbsent(id, k -> new ArrayList<>()).add(item);
        }

        private void expireListings() {
            long now = System.currentTimeMillis();
            boolean changed = false;
            Iterator<Listing> it = listings.values().iterator();
            while (it.hasNext()) {
                Listing l = it.next();
                if (now - l.created >= expireMillis()) {
                    addClaim(l.seller, l.item);
                    it.remove();
                    changed = true;
                    Player p = Bukkit.getPlayer(l.seller);
                    if (p != null) msg(p, "§eOne of your listings expired. Use §6/ah claim §eto get the item back.");
                }
            }
            if (changed) save();
        }

        private String timeLeft(Listing l) {
            long left = expireMillis() - (System.currentTimeMillis() - l.created);
            if (left < 0) left = 0;
            long hours = left / 3_600_000L;
            long mins = (left % 3_600_000L) / 60_000L;
            return hours + "h " + mins + "m";
        }

        private Component line(String text, NamedTextColor color) {
            return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
        }

        private ItemStack button(Material mat, String name, NamedTextColor color, String... lore) {
            ItemStack item = new ItemStack(mat);
            ItemMeta meta = item.getItemMeta();
            meta.displayName(line(name, color));
            List<Component> lines = new ArrayList<>();
            for (String s : lore) lines.add(line(s, NamedTextColor.GRAY));
            meta.lore(lines);
            item.setItemMeta(meta);
            return item;
        }

        private void giveOrDrop(Player p, ItemStack item) {
            Map<Integer, ItemStack> left = p.getInventory().addItem(item);
            left.values().forEach(i -> p.getWorld().dropItemNaturally(p.getLocation(), i));
        }

        // ---------- GUI ----------

        private List<Listing> visibleListings(Player p, boolean mine) {
            List<Listing> out = new ArrayList<>();
            for (Listing l : listings.values()) {
                if (!mine || l.seller.equals(p.getUniqueId())) out.add(l);
            }
            out.sort((a, b) -> Long.compare(b.created, a.created)); // newest first
            return out;
        }

        private void openGui(Player p, int page, boolean mine) {
            List<Listing> all = visibleListings(p, mine);
            int maxPage = Math.max(0, (all.size() - 1) / PAGE_SIZE);
            page = Math.max(0, Math.min(page, maxPage));

            AHHolder holder = new AHHolder();
            holder.page = page;
            holder.mine = mine;
            Inventory inv = Bukkit.createInventory(holder, 54,
                    Component.text(mine ? "Your Listings" : "Auction House"));
            holder.inv = inv;

            int start = page * PAGE_SIZE;
            for (int i = 0; i < PAGE_SIZE && start + i < all.size(); i++) {
                Listing l = all.get(start + i);
                holder.shown.add(l);

                ItemStack display = l.item.clone();
                ItemMeta meta = display.getItemMeta();
                List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
                lore.add(Component.empty());
                lore.add(line("Price: " + Economy.format(l.price) + " shards", NamedTextColor.YELLOW));
                lore.add(line("Seller: " + l.sellerName, NamedTextColor.GRAY));
                lore.add(line("Expires in: " + timeLeft(l), NamedTextColor.GRAY));
                lore.add(Component.empty());
                if (mine) {
                    lore.add(line("Click to cancel this listing", NamedTextColor.RED));
                } else if (l.seller.equals(p.getUniqueId())) {
                    lore.add(line("This is your listing", NamedTextColor.DARK_GRAY));
                } else {
                    lore.add(line("Click to buy", NamedTextColor.GREEN));
                }
                meta.lore(lore);
                display.setItemMeta(meta);
                inv.setItem(i, display);
            }

            ItemStack filler = button(Material.GRAY_STAINED_GLASS_PANE, " ", NamedTextColor.GRAY);
            for (int s = 45; s < 54; s++) inv.setItem(s, filler);

            if (page > 0) inv.setItem(SLOT_PREV, button(Material.ARROW, "Previous page", NamedTextColor.GREEN));
            if (page < maxPage) inv.setItem(SLOT_NEXT, button(Material.ARROW, "Next page", NamedTextColor.GREEN));
            inv.setItem(SLOT_MODE, mine
                    ? button(Material.EMERALD, "All listings", NamedTextColor.GREEN, "Browse everything for sale")
                    : button(Material.CHEST, "My listings", NamedTextColor.GOLD, "View or cancel your listings"));
            inv.setItem(SLOT_INFO, button(Material.PAPER, "Page " + (page + 1) + "/" + (maxPage + 1), NamedTextColor.WHITE,
                    "Your balance: " + Economy.format(economy.get(p.getUniqueId())) + " shards"));
            int pending = claims.getOrDefault(p.getUniqueId(), List.of()).size();
            inv.setItem(SLOT_CLAIM, button(Material.HOPPER, "Claim items (" + pending + ")", NamedTextColor.AQUA,
                    "Collect expired or returned items"));

            p.openInventory(inv);
        }

        @EventHandler
        public void onClick(InventoryClickEvent e) {
            if (!(e.getView().getTopInventory().getHolder() instanceof AHHolder holder)) return;
            e.setCancelled(true); // nothing can be moved in or out of the GUI
            if (!(e.getWhoClicked() instanceof Player p)) return;
            if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;

            int slot = e.getSlot();

            if (slot < PAGE_SIZE) {
                if (slot >= holder.shown.size()) return;
                Listing l = holder.shown.get(slot);
                if (holder.mine) cancelListing(p, l, holder);
                else buy(p, l, holder);
                return;
            }

            switch (slot) {
                case SLOT_PREV -> reopen(p, holder.page - 1, holder.mine);
                case SLOT_NEXT -> reopen(p, holder.page + 1, holder.mine);
                case SLOT_MODE -> reopen(p, 0, !holder.mine);
                case SLOT_CLAIM -> {
                    claimItems(p);
                    reopen(p, holder.page, holder.mine);
                }
                default -> { }
            }
        }

        @EventHandler
        public void onDrag(InventoryDragEvent e) {
            if (e.getView().getTopInventory().getHolder() instanceof AHHolder) e.setCancelled(true);
        }

        private void reopen(Player p, int page, boolean mine) {
            Bukkit.getScheduler().runTask(plugin, () -> openGui(p, page, mine));
        }

        // ---------- Actions ----------

        private void buy(Player buyer, Listing l, AHHolder holder) {
            if (!listings.containsKey(l.id)) {
                msg(buyer, "§cThat listing is no longer available.");
                reopen(buyer, holder.page, holder.mine);
                return;
            }
            if (l.seller.equals(buyer.getUniqueId())) {
                msg(buyer, "§cYou can't buy your own listing. Use §6My listings §cto cancel it.");
                return;
            }
            if (!economy.take(buyer.getUniqueId(), l.price)) {
                msg(buyer, "§cYou need §e" + Economy.format(l.price) + " shards §cfor that.");
                return;
            }

            listings.remove(l.id);
            long tax = l.price * plugin.getConfig().getLong("auction.tax-percent", 5) / 100;
            economy.add(l.seller, l.price - tax);
            giveOrDrop(buyer, l.item.clone());
            save();

            msg(buyer, "Bought for §e" + Economy.format(l.price) + " shards§f.");
            Player seller = Bukkit.getPlayer(l.seller);
            if (seller != null) {
                msg(seller, buyer.getName() + " bought your item for §e" + Economy.format(l.price)
                        + " shards §f(you received §e" + Economy.format(l.price - tax) + "§f).");
            }
            reopen(buyer, holder.page, holder.mine);
        }

        private void cancelListing(Player p, Listing l, AHHolder holder) {
            if (listings.remove(l.id) == null) {
                reopen(p, holder.page, holder.mine);
                return;
            }
            giveOrDrop(p, l.item.clone());
            save();
            msg(p, "Listing cancelled and item returned.");
            reopen(p, holder.page, holder.mine);
        }

        private void claimItems(Player p) {
            List<ItemStack> items = claims.remove(p.getUniqueId());
            if (items == null || items.isEmpty()) {
                msg(p, "§7You have nothing to claim.");
                return;
            }
            items.forEach(i -> giveOrDrop(p, i));
            save();
            msg(p, "Claimed " + items.size() + " item stack(s).");
        }

        private void createListing(Player p, long price) {
            ItemStack hand = p.getInventory().getItemInMainHand();
            if (hand.getType() == Material.AIR) {
                msg(p, "§cHold the item you want to sell.");
                return;
            }
            long maxPrice = plugin.getConfig().getLong("auction.max-price", 1_000_000_000L);
            if (price > maxPrice) {
                msg(p, "§cMax price is §e" + Economy.format(maxPrice) + " shards§c.");
                return;
            }
            int max = plugin.getConfig().getInt("auction.max-listings", 5);
            long current = listings.values().stream().filter(l -> l.seller.equals(p.getUniqueId())).count();
            if (current >= max) {
                msg(p, "§cYou can only have " + max + " active listings.");
                return;
            }

            Listing l = new Listing();
            l.id = UUID.randomUUID().toString();
            l.seller = p.getUniqueId();
            l.sellerName = p.getName();
            l.item = hand.clone();
            l.price = price;
            l.created = System.currentTimeMillis();
            listings.put(l.id, l);
            p.getInventory().setItemInMainHand(null);
            save();
            msg(p, "Listed for §e" + Economy.format(price) + " shards§f.");
        }

        // ---------- Command ----------

        @Override
        public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd,
                                 @NotNull String label, @NotNull String[] args) {
            if (!(sender instanceof Player p)) {
                msg(sender, "Players only.");
                return true;
            }
            if (args.length == 0) {
                openGui(p, 0, false);
                return true;
            }
            switch (args[0].toLowerCase()) {
                case "sell" -> {
                    if (args.length < 2) { msg(p, "§cUsage: /ah sell <price>"); return true; }
                    long price;
                    try {
                        price = Long.parseLong(args[1]);
                        if (price <= 0) throw new NumberFormatException();
                    } catch (NumberFormatException ex) {
                        msg(p, "§cEnter a whole number greater than 0.");
                        return true;
                    }
                    createListing(p, price);
                }
                case "mine" -> openGui(p, 0, true);
                case "claim" -> claimItems(p);
                default -> msg(p, "§cUsage: /ah [sell <price>|mine|claim]");
            }
            return true;
        }
    }

    // =====================================================================
    //  Homes
    // =====================================================================

    public static class Homes implements CommandExecutor, TabCompleter {

        private static final String H_PREFIX = "§a[Home] §f";

        private static class Home {
            String world;
            double x, y, z;
            float yaw, pitch;
        }

        private final ShardCore plugin;
        private final File file;
        private final Map<UUID, Map<String, Home>> homes = new HashMap<>();

        public Homes(ShardCore plugin) {
            this.plugin = plugin;
            this.file = new File(plugin.getDataFolder(), "homes.yml");
            load();
        }

        private void load() {
            if (!file.exists()) return;
            YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
            for (String uuid : yml.getKeys(false)) {
                ConfigurationSection sec = yml.getConfigurationSection(uuid);
                if (sec == null) continue;
                Map<String, Home> map = new LinkedHashMap<>();
                for (String name : sec.getKeys(false)) {
                    ConfigurationSection h = sec.getConfigurationSection(name);
                    if (h == null) continue;
                    Home home = new Home();
                    home.world = h.getString("world", "world");
                    home.x = h.getDouble("x");
                    home.y = h.getDouble("y");
                    home.z = h.getDouble("z");
                    home.yaw = (float) h.getDouble("yaw");
                    home.pitch = (float) h.getDouble("pitch");
                    map.put(name, home);
                }
                try {
                    homes.put(UUID.fromString(uuid), map);
                } catch (IllegalArgumentException ignored) {
                }
            }
        }

        public void save() {
            YamlConfiguration yml = new YamlConfiguration();
            for (Map.Entry<UUID, Map<String, Home>> e : homes.entrySet()) {
                for (Map.Entry<String, Home> h : e.getValue().entrySet()) {
                    String path = e.getKey() + "." + h.getKey() + ".";
                    Home home = h.getValue();
                    yml.set(path + "world", home.world);
                    yml.set(path + "x", home.x);
                    yml.set(path + "y", home.y);
                    yml.set(path + "z", home.z);
                    yml.set(path + "yaw", home.yaw);
                    yml.set(path + "pitch", home.pitch);
                }
            }
            try {
                plugin.getDataFolder().mkdirs();
                yml.save(file);
            } catch (IOException ex) {
                plugin.getLogger().severe("Could not save homes: " + ex.getMessage());
            }
        }

        private void msg(CommandSender s, String text) {
            s.sendMessage(H_PREFIX + text);
        }

        private Map<String, Home> homesOf(Player p) {
            return homes.computeIfAbsent(p.getUniqueId(), k -> new LinkedHashMap<>());
        }

        private int maxHomes(Player p) {
            if (p.hasPermission("shardcore.homes.unlimited")) return Integer.MAX_VALUE;
            return plugin.getConfig().getInt("homes.max", 3);
        }

        @Override
        public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd,
                                 @NotNull String label, @NotNull String[] args) {
            if (!(sender instanceof Player p)) {
                msg(sender, "Players only.");
                return true;
            }
            switch (cmd.getName().toLowerCase()) {
                case "sethome" -> setHome(p, args);
                case "home" -> goHome(p, args);
                case "delhome" -> delHome(p, args);
                case "homes" -> listHomes(p);
            }
            return true;
        }

        private void setHome(Player p, String[] args) {
            String name = args.length > 0 ? args[0].toLowerCase() : "home";
            if (!name.matches("[a-z0-9_-]{1,16}")) {
                msg(p, "§cHome names can be 1-16 letters, numbers, - or _.");
                return;
            }
            Map<String, Home> mine = homesOf(p);
            if (!mine.containsKey(name) && mine.size() >= maxHomes(p)) {
                msg(p, "§cYou can only have " + maxHomes(p) + " homes. Use §6/delhome <name> §cto free one up.");
                return;
            }
            Location l = p.getLocation();
            Home h = new Home();
            h.world = l.getWorld().getName();
            h.x = l.getX();
            h.y = l.getY();
            h.z = l.getZ();
            h.yaw = l.getYaw();
            h.pitch = l.getPitch();
            boolean existed = mine.put(name, h) != null;
            save();
            msg(p, (existed ? "Updated" : "Set") + " home §a" + name + "§f.");
        }

        private void goHome(Player p, String[] args) {
            Map<String, Home> mine = homesOf(p);
            if (mine.isEmpty()) {
                msg(p, "§cYou have no homes. Use §6/sethome §cto make one.");
                return;
            }

            String name;
            if (args.length > 0) {
                name = args[0].toLowerCase();
            } else if (mine.size() == 1) {
                name = mine.keySet().iterator().next();
            } else if (mine.containsKey("home")) {
                name = "home";
            } else {
                msg(p, "Which home? §a" + String.join("§f, §a", mine.keySet()));
                return;
            }

            Home h = mine.get(name);
            if (h == null) {
                msg(p, "§cNo home named §e" + name + "§c. Your homes: §a" + String.join("§f, §a", mine.keySet()));
                return;
            }
            World w = Bukkit.getWorld(h.world);
            if (w == null) {
                msg(p, "§cThat home's world isn't loaded.");
                return;
            }
            p.teleportAsync(new Location(w, h.x, h.y, h.z, h.yaw, h.pitch)).thenAccept(ok ->
                    msg(p, ok ? "Teleported to home §a" + name + "§f." : "§cTeleport failed."));
        }

        private void delHome(Player p, String[] args) {
            if (args.length == 0) {
                msg(p, "§cUsage: /delhome <name>");
                return;
            }
            String name = args[0].toLowerCase();
            if (homesOf(p).remove(name) == null) {
                msg(p, "§cNo home named §e" + name + "§c.");
                return;
            }
            save();
            msg(p, "Deleted home §a" + name + "§f.");
        }

        private void listHomes(Player p) {
            Map<String, Home> mine = homesOf(p);
            if (mine.isEmpty()) {
                msg(p, "You have no homes. Use §a/sethome §fto make one.");
                return;
            }
            String max = maxHomes(p) == Integer.MAX_VALUE ? "∞" : String.valueOf(maxHomes(p));
            msg(p, "Homes (" + mine.size() + "/" + max + "): §a" + String.join("§f, §a", mine.keySet()));
        }

        @Override
        public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command cmd,
                                          @NotNull String alias, @NotNull String[] args) {
            if (!(sender instanceof Player p) || args.length != 1) return List.of();
            String name = cmd.getName().toLowerCase();
            if (!name.equals("home") && !name.equals("delhome") && !name.equals("sethome")) return List.of();
            List<String> out = new ArrayList<>();
            for (String h : homesOf(p).keySet()) {
                if (h.startsWith(args[0].toLowerCase())) out.add(h);
            }
            return out;
        }
    }

    // =====================================================================
    //  /tpa, /tpahere, /tpaccept, /tpdeny, /tpcancel
    // =====================================================================

    public static class Tpa implements CommandExecutor, TabCompleter {

        private static final String T_PREFIX = "§d[TPA] §f";

        private static class Request {
            UUID sender;
            boolean here; // true = /tpahere (target teleports to sender)
            long created;
        }

        private final ShardCore plugin;
        /** Pending requests, keyed by the player who must answer them. */
        private final Map<UUID, Request> requests = new HashMap<>();

        public Tpa(ShardCore plugin) {
            this.plugin = plugin;
        }

        private void msg(CommandSender s, String text) {
            s.sendMessage(T_PREFIX + text);
        }

        private boolean expired(Request r) {
            long ms = plugin.getConfig().getLong("tpa.expire-seconds", 60) * 1000L;
            return System.currentTimeMillis() - r.created > ms;
        }

        @Override
        public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd,
                                 @NotNull String label, @NotNull String[] args) {
            if (!(sender instanceof Player p)) {
                msg(sender, "Players only.");
                return true;
            }
            switch (cmd.getName().toLowerCase()) {
                case "tpa" -> send(p, args, false);
                case "tpahere" -> send(p, args, true);
                case "tpaccept" -> accept(p);
                case "tpdeny" -> deny(p);
                case "tpcancel" -> cancel(p);
            }
            return true;
        }

        private void send(Player p, String[] args, boolean here) {
            if (args.length < 1) {
                msg(p, "§cUsage: /" + (here ? "tpahere" : "tpa") + " <player>");
                return;
            }
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target == null) { msg(p, "§cThat player is not online."); return; }
            if (target.equals(p)) { msg(p, "§cYou can't send a request to yourself."); return; }

            Request r = new Request();
            r.sender = p.getUniqueId();
            r.here = here;
            r.created = System.currentTimeMillis();
            requests.put(target.getUniqueId(), r);

            long secs = plugin.getConfig().getLong("tpa.expire-seconds", 60);
            msg(p, "Request sent to §d" + target.getName() + "§f. It expires in " + secs + "s.");

            Component text = LegacyComponentSerializer.legacySection().deserialize(
                    T_PREFIX + "§d" + p.getName() + " §f"
                            + (here ? "wants you to teleport to them. " : "wants to teleport to you. "));
            Component accept = Component.text("[ACCEPT]", NamedTextColor.GREEN)
                    .clickEvent(ClickEvent.runCommand("/tpaccept"));
            Component deny = Component.text("[DENY]", NamedTextColor.RED)
                    .clickEvent(ClickEvent.runCommand("/tpdeny"));
            target.sendMessage(text.append(accept).append(Component.text(" ")).append(deny));
        }

        private void accept(Player target) {
            Request r = requests.remove(target.getUniqueId());
            if (r == null || expired(r)) {
                msg(target, "§cYou have no pending teleport requests.");
                return;
            }
            Player requester = Bukkit.getPlayer(r.sender);
            if (requester == null) {
                msg(target, "§cThat player is no longer online.");
                return;
            }

            Player mover = r.here ? target : requester;
            Player dest = r.here ? requester : target;
            mover.teleportAsync(dest.getLocation()).thenAccept(ok -> {
                if (ok) {
                    msg(mover, "Teleported to §d" + dest.getName() + "§f.");
                    msg(dest, "§d" + mover.getName() + " §fteleported to you.");
                } else {
                    msg(target, "§cTeleport failed.");
                    msg(requester, "§cTeleport failed.");
                }
            });
        }

        private void deny(Player target) {
            Request r = requests.remove(target.getUniqueId());
            if (r == null || expired(r)) {
                msg(target, "§cYou have no pending teleport requests.");
                return;
            }
            msg(target, "Request denied.");
            Player requester = Bukkit.getPlayer(r.sender);
            if (requester != null) msg(requester, "§d" + target.getName() + " §fdenied your request.");
        }

        private void cancel(Player p) {
            boolean removed = requests.values().removeIf(r -> r.sender.equals(p.getUniqueId()));
            msg(p, removed ? "Your teleport request was cancelled." : "§cYou have no outgoing requests.");
        }

        @Override
        public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command cmd,
                                          @NotNull String alias, @NotNull String[] args) {
            String name = cmd.getName().toLowerCase();
            if (args.length != 1 || !(name.equals("tpa") || name.equals("tpahere"))) return List.of();
            List<String> out = new ArrayList<>();
            for (Player online : Bukkit.getOnlinePlayers()) {
                if (online.equals(sender)) continue;
                if (online.getName().toLowerCase().startsWith(args[0].toLowerCase())) out.add(online.getName());
            }
            return out;
        }
    }

    // =====================================================================
    //  Teams
    // =====================================================================

    public static class Teams implements CommandExecutor, TabCompleter, Listener {

        private static final String T_PREFIX = "§9[Team] §f";
        private static final List<String> SUBS = List.of("create", "invite", "accept", "deny", "leave", "kick",
                "disband", "transfer", "info", "list", "ff", "sethome", "home", "help");

        private static class Team {
            String name;
            UUID owner;
            final Set<UUID> members = new LinkedHashSet<>();
            boolean friendlyFire = false;
            boolean hasHome = false;
            String homeWorld;
            double hx, hy, hz;
            float hyaw, hpitch;
        }

        private final ShardCore plugin;
        private final File file;
        private final Map<String, Team> teams = new LinkedHashMap<>();       // key = lowercase name
        private final Map<UUID, String> byPlayer = new HashMap<>();          // player -> team key
        private final Map<UUID, Map<String, Long>> invites = new HashMap<>(); // invitee -> (team key -> time)
        private final Set<UUID> teamChatMode = new HashSet<>();

        public Teams(ShardCore plugin) {
            this.plugin = plugin;
            this.file = new File(plugin.getDataFolder(), "teams.yml");
            load();
        }

        // ---------- Storage ----------

        private void load() {
            if (!file.exists()) return;
            YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
            ConfigurationSection root = yml.getConfigurationSection("teams");
            if (root == null) return;
            for (String key : root.getKeys(false)) {
                ConfigurationSection sec = root.getConfigurationSection(key);
                if (sec == null) continue;
                try {
                    Team t = new Team();
                    t.name = sec.getString("name", key);
                    t.owner = UUID.fromString(sec.getString("owner", ""));
                    for (String m : sec.getStringList("members")) t.members.add(UUID.fromString(m));
                    t.members.add(t.owner);
                    t.friendlyFire = sec.getBoolean("friendly-fire", false);
                    if (sec.isConfigurationSection("home")) {
                        ConfigurationSection h = sec.getConfigurationSection("home");
                        t.hasHome = true;
                        t.homeWorld = h.getString("world");
                        t.hx = h.getDouble("x");
                        t.hy = h.getDouble("y");
                        t.hz = h.getDouble("z");
                        t.hyaw = (float) h.getDouble("yaw");
                        t.hpitch = (float) h.getDouble("pitch");
                    }
                    teams.put(key, t);
                    for (UUID m : t.members) byPlayer.put(m, key);
                } catch (IllegalArgumentException ignored) {
                }
            }
        }

        public void save() {
            YamlConfiguration yml = new YamlConfiguration();
            for (Map.Entry<String, Team> e : teams.entrySet()) {
                Team t = e.getValue();
                String p = "teams." + e.getKey() + ".";
                yml.set(p + "name", t.name);
                yml.set(p + "owner", t.owner.toString());
                List<String> members = new ArrayList<>();
                for (UUID m : t.members) members.add(m.toString());
                yml.set(p + "members", members);
                yml.set(p + "friendly-fire", t.friendlyFire);
                if (t.hasHome) {
                    yml.set(p + "home.world", t.homeWorld);
                    yml.set(p + "home.x", t.hx);
                    yml.set(p + "home.y", t.hy);
                    yml.set(p + "home.z", t.hz);
                    yml.set(p + "home.yaw", t.hyaw);
                    yml.set(p + "home.pitch", t.hpitch);
                }
            }
            try {
                plugin.getDataFolder().mkdirs();
                yml.save(file);
            } catch (IOException ex) {
                plugin.getLogger().severe("Could not save teams: " + ex.getMessage());
            }
        }

        // ---------- Helpers ----------

        private void msg(CommandSender s, String text) {
            s.sendMessage(T_PREFIX + text);
        }

        private Team teamOf(Player p) {
            String key = byPlayer.get(p.getUniqueId());
            return key == null ? null : teams.get(key);
        }

        private String nameOf(UUID id) {
            String n = Bukkit.getOfflinePlayer(id).getName();
            return n == null ? "Unknown" : n;
        }

        private void broadcast(Team t, String text) {
            for (UUID id : t.members) {
                Player p = Bukkit.getPlayer(id);
                if (p != null) msg(p, text);
            }
        }

        private UUID findMember(Team t, String name) {
            for (UUID id : t.members) {
                if (nameOf(id).equalsIgnoreCase(name)) return id;
            }
            return null;
        }

        private boolean inviteValid(Long created) {
            long ms = plugin.getConfig().getLong("teams.invite-expire-seconds", 60) * 1000L;
            return created != null && System.currentTimeMillis() - created <= ms;
        }

        private int maxMembers() {
            return plugin.getConfig().getInt("teams.max-members", 5);
        }

        private void removeFromTeam(Team t, UUID id) {
            t.members.remove(id);
            byPlayer.remove(id);
            teamChatMode.remove(id);
        }

        // ---------- Commands ----------

        @Override
        public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd,
                                 @NotNull String label, @NotNull String[] args) {
            if (!(sender instanceof Player p)) {
                msg(sender, "Players only.");
                return true;
            }
            if (cmd.getName().equalsIgnoreCase("tc")) {
                teamChat(p, args);
                return true;
            }
            if (args.length == 0) {
                help(p);
                return true;
            }
            switch (args[0].toLowerCase()) {
                case "create" -> create(p, args);
                case "invite" -> invite(p, args);
                case "accept" -> accept(p, args);
                case "deny" -> deny(p, args);
                case "leave" -> leave(p);
                case "kick" -> kick(p, args);
                case "disband" -> disband(p);
                case "transfer" -> transfer(p, args);
                case "info" -> info(p, args);
                case "list" -> list(p);
                case "ff" -> toggleFf(p);
                case "sethome" -> setHome(p);
                case "home" -> goHome(p);
                default -> help(p);
            }
            return true;
        }

        private void help(Player p) {
            msg(p, "§9Team commands:");
            p.sendMessage("§7/team create <name> §f- make a team");
            p.sendMessage("§7/team invite <player> §f- invite someone (owner)");
            p.sendMessage("§7/team accept [team] / deny [team] §f- answer an invite");
            p.sendMessage("§7/team leave §f- leave your team");
            p.sendMessage("§7/team kick <player> §f- remove a member (owner)");
            p.sendMessage("§7/team transfer <player> §f- give ownership (owner)");
            p.sendMessage("§7/team disband §f- delete the team (owner)");
            p.sendMessage("§7/team info [team] / list §f- see teams");
            p.sendMessage("§7/team ff §f- toggle friendly fire (owner)");
            p.sendMessage("§7/team sethome / home §f- team home (owner sets)");
            p.sendMessage("§7/tc [message] §f- team chat (no message toggles team chat mode)");
        }

        private void create(Player p, String[] args) {
            if (teamOf(p) != null) { msg(p, "§cYou're already in a team. Leave it first."); return; }
            if (args.length < 2) { msg(p, "§cUsage: /team create <name>"); return; }
            String name = args[1];
            if (!name.matches("[A-Za-z0-9_]{3,12}")) {
                msg(p, "§cTeam names are 3-12 letters, numbers or _.");
                return;
            }
            String key = name.toLowerCase();
            if (teams.containsKey(key)) { msg(p, "§cThat team name is taken."); return; }

            Team t = new Team();
            t.name = name;
            t.owner = p.getUniqueId();
            t.members.add(p.getUniqueId());
            teams.put(key, t);
            byPlayer.put(p.getUniqueId(), key);
            save();
            msg(p, "Created team §b" + name + "§f. Invite people with §7/team invite <player>§f.");
        }

        private void invite(Player p, String[] args) {
            Team t = teamOf(p);
            if (t == null) { msg(p, "§cYou're not in a team."); return; }
            if (!t.owner.equals(p.getUniqueId())) { msg(p, "§cOnly the team owner can invite."); return; }
            if (args.length < 2) { msg(p, "§cUsage: /team invite <player>"); return; }
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) { msg(p, "§cThat player is not online."); return; }
            if (byPlayer.containsKey(target.getUniqueId())) { msg(p, "§cThat player is already in a team."); return; }
            if (t.members.size() >= maxMembers()) { msg(p, "§cYour team is full (" + maxMembers() + " members)."); return; }

            invites.computeIfAbsent(target.getUniqueId(), k -> new HashMap<>())
                    .put(t.name.toLowerCase(), System.currentTimeMillis());
            msg(p, "Invited §b" + target.getName() + "§f.");

            Component text = LegacyComponentSerializer.legacySection().deserialize(
                    T_PREFIX + "You were invited to team §b" + t.name + "§f. ");
            Component accept = Component.text("[ACCEPT]", NamedTextColor.GREEN)
                    .clickEvent(ClickEvent.runCommand("/team accept " + t.name));
            Component deny = Component.text("[DENY]", NamedTextColor.RED)
                    .clickEvent(ClickEvent.runCommand("/team deny " + t.name));
            target.sendMessage(text.append(accept).append(Component.text(" ")).append(deny));
        }

        /** Valid (unexpired, still existing) invite team keys for a player. */
        private List<String> validInvites(UUID id) {
            Map<String, Long> map = invites.get(id);
            List<String> out = new ArrayList<>();
            if (map == null) return out;
            map.entrySet().removeIf(e -> !inviteValid(e.getValue()) || !teams.containsKey(e.getKey()));
            out.addAll(map.keySet());
            return out;
        }

        private void accept(Player p, String[] args) {
            if (teamOf(p) != null) { msg(p, "§cYou're already in a team. Leave it first."); return; }
            List<String> valid = validInvites(p.getUniqueId());
            if (valid.isEmpty()) { msg(p, "§cYou have no pending team invites."); return; }

            String key;
            if (args.length >= 2) {
                key = args[1].toLowerCase();
                if (!valid.contains(key)) { msg(p, "§cNo invite from that team."); return; }
            } else if (valid.size() == 1) {
                key = valid.get(0);
            } else {
                msg(p, "Which team? Use §7/team accept <team>§f. Invites: §b" + String.join("§f, §b", valid));
                return;
            }

            Team t = teams.get(key);
            if (t.members.size() >= maxMembers()) { msg(p, "§cThat team is full."); return; }

            t.members.add(p.getUniqueId());
            byPlayer.put(p.getUniqueId(), key);
            invites.remove(p.getUniqueId());
            save();
            broadcast(t, "§b" + p.getName() + " §fjoined the team!");
        }

        private void deny(Player p, String[] args) {
            Map<String, Long> map = invites.get(p.getUniqueId());
            if (map == null || map.isEmpty()) { msg(p, "§cYou have no pending team invites."); return; }
            if (args.length >= 2) map.remove(args[1].toLowerCase());
            else map.clear();
            msg(p, "Invite denied.");
        }

        private void leave(Player p) {
            Team t = teamOf(p);
            if (t == null) { msg(p, "§cYou're not in a team."); return; }
            if (t.owner.equals(p.getUniqueId())) {
                msg(p, "§cYou own this team. Use §7/team transfer <player> §cor §7/team disband§c.");
                return;
            }
            removeFromTeam(t, p.getUniqueId());
            save();
            msg(p, "You left §b" + t.name + "§f.");
            broadcast(t, "§b" + p.getName() + " §fleft the team.");
        }

        private void kick(Player p, String[] args) {
            Team t = teamOf(p);
            if (t == null) { msg(p, "§cYou're not in a team."); return; }
            if (!t.owner.equals(p.getUniqueId())) { msg(p, "§cOnly the team owner can kick."); return; }
            if (args.length < 2) { msg(p, "§cUsage: /team kick <player>"); return; }
            UUID target = findMember(t, args[1]);
            if (target == null) { msg(p, "§cThat player isn't in your team."); return; }
            if (target.equals(p.getUniqueId())) { msg(p, "§cYou can't kick yourself. Use §7/team disband§c."); return; }

            String name = nameOf(target);
            removeFromTeam(t, target);
            save();
            Player online = Bukkit.getPlayer(target);
            if (online != null) msg(online, "§cYou were kicked from team §b" + t.name + "§c.");
            broadcast(t, "§b" + name + " §fwas kicked from the team.");
            msg(p, "Kicked §b" + name + "§f.");
        }

        private void disband(Player p) {
            Team t = teamOf(p);
            if (t == null) { msg(p, "§cYou're not in a team."); return; }
            if (!t.owner.equals(p.getUniqueId())) { msg(p, "§cOnly the team owner can disband."); return; }
            broadcast(t, "§cThe team §b" + t.name + " §cwas disbanded.");
            for (UUID id : new ArrayList<>(t.members)) {
                byPlayer.remove(id);
                teamChatMode.remove(id);
            }
            teams.remove(t.name.toLowerCase());
            save();
        }

        private void transfer(Player p, String[] args) {
            Team t = teamOf(p);
            if (t == null) { msg(p, "§cYou're not in a team."); return; }
            if (!t.owner.equals(p.getUniqueId())) { msg(p, "§cOnly the team owner can transfer ownership."); return; }
            if (args.length < 2) { msg(p, "§cUsage: /team transfer <player>"); return; }
            UUID target = findMember(t, args[1]);
            if (target == null) { msg(p, "§cThat player isn't in your team."); return; }
            if (target.equals(p.getUniqueId())) { msg(p, "§cYou already own the team."); return; }
            t.owner = target;
            save();
            broadcast(t, "§b" + nameOf(target) + " §fis now the team owner.");
        }

        private void info(Player p, String[] args) {
            Team t;
            if (args.length >= 2) {
                t = teams.get(args[1].toLowerCase());
                if (t == null) { msg(p, "§cNo team with that name."); return; }
            } else {
                t = teamOf(p);
                if (t == null) { msg(p, "§cYou're not in a team. Use §7/team info <team>§c."); return; }
            }
            List<String> names = new ArrayList<>();
            for (UUID id : t.members) {
                boolean online = Bukkit.getPlayer(id) != null;
                String prefix = id.equals(t.owner) ? "§6★ " : "";
                names.add(prefix + (online ? "§a" : "§7") + nameOf(id));
            }
            msg(p, "§b" + t.name + " §f(" + t.members.size() + "/" + maxMembers() + ")");
            p.sendMessage("§7Members: " + String.join("§f, ", names));
            p.sendMessage("§7Friendly fire: " + (t.friendlyFire ? "§cOn" : "§aOff")
                    + " §7| Home: " + (t.hasHome ? "§aSet" : "§7None"));
        }

        private void list(Player p) {
            if (teams.isEmpty()) { msg(p, "There are no teams yet. Make one with §7/team create <name>§f."); return; }
            List<Team> sorted = new ArrayList<>(teams.values());
            sorted.sort((a, b) -> Integer.compare(b.members.size(), a.members.size()));
            msg(p, "§9Teams:");
            int shown = 0;
            for (Team t : sorted) {
                if (shown++ >= 20) break;
                p.sendMessage("§b" + t.name + " §7- " + t.members.size() + " member(s)");
            }
        }

        private void toggleFf(Player p) {
            Team t = teamOf(p);
            if (t == null) { msg(p, "§cYou're not in a team."); return; }
            if (!t.owner.equals(p.getUniqueId())) { msg(p, "§cOnly the team owner can change this."); return; }
            t.friendlyFire = !t.friendlyFire;
            save();
            broadcast(t, "Friendly fire is now " + (t.friendlyFire ? "§cON" : "§aOFF") + "§f.");
        }

        private void setHome(Player p) {
            Team t = teamOf(p);
            if (t == null) { msg(p, "§cYou're not in a team."); return; }
            if (!t.owner.equals(p.getUniqueId())) { msg(p, "§cOnly the team owner can set the team home."); return; }
            Location l = p.getLocation();
            t.hasHome = true;
            t.homeWorld = l.getWorld().getName();
            t.hx = l.getX();
            t.hy = l.getY();
            t.hz = l.getZ();
            t.hyaw = l.getYaw();
            t.hpitch = l.getPitch();
            save();
            broadcast(t, "Team home set.");
        }

        private void goHome(Player p) {
            Team t = teamOf(p);
            if (t == null) { msg(p, "§cYou're not in a team."); return; }
            if (!t.hasHome) { msg(p, "§cYour team has no home yet."); return; }
            World w = Bukkit.getWorld(t.homeWorld);
            if (w == null) { msg(p, "§cThe team home's world isn't loaded."); return; }
            p.teleportAsync(new Location(w, t.hx, t.hy, t.hz, t.hyaw, t.hpitch)).thenAccept(ok ->
                    msg(p, ok ? "Teleported to the team home." : "§cTeleport failed."));
        }

        // ---------- Team chat ----------

        private void teamChat(Player p, String[] args) {
            Team t = teamOf(p);
            if (t == null) { msg(p, "§cYou're not in a team."); return; }
            if (args.length == 0) {
                if (teamChatMode.remove(p.getUniqueId())) {
                    msg(p, "Team chat §coff§f. You're back in public chat.");
                } else {
                    teamChatMode.add(p.getUniqueId());
                    msg(p, "Team chat §aon§f. Everything you type goes to your team. Use §7/tc §fto switch back.");
                }
                return;
            }
            sendTeamMessage(t, p, String.join(" ", args));
        }

        private void sendTeamMessage(Team t, Player from, String text) {
            String line = T_PREFIX.replace("§f", "") + "§b" + from.getName() + "§f: " + text;
            for (UUID id : t.members) {
                Player online = Bukkit.getPlayer(id);
                if (online != null) online.sendMessage(line);
            }
        }

        @EventHandler
        public void onChat(AsyncChatEvent e) {
            Player p = e.getPlayer();
            if (!teamChatMode.contains(p.getUniqueId())) return;
            String text = PlainTextComponentSerializer.plainText().serialize(e.message());
            e.setCancelled(true);
            // Hop to the main thread before touching team data
            Bukkit.getScheduler().runTask(plugin, () -> {
                Team t = teamOf(p);
                if (t == null) {
                    teamChatMode.remove(p.getUniqueId());
                    msg(p, "§cYou're not in a team anymore, so team chat was turned off. Send your message again.");
                    return;
                }
                sendTeamMessage(t, p, text);
            });
        }

        @EventHandler
        public void onQuit(PlayerQuitEvent e) {
            teamChatMode.remove(e.getPlayer().getUniqueId());
        }

        // ---------- Friendly fire ----------

        @EventHandler(ignoreCancelled = true)
        public void onDamage(EntityDamageByEntityEvent e) {
            if (!(e.getEntity() instanceof Player victim)) return;

            Player attacker = null;
            if (e.getDamager() instanceof Player pl) {
                attacker = pl;
            } else if (e.getDamager() instanceof Projectile proj && proj.getShooter() instanceof Player shooter) {
                attacker = shooter;
            }
            if (attacker == null || attacker.equals(victim)) return;

            String a = byPlayer.get(attacker.getUniqueId());
            String v = byPlayer.get(victim.getUniqueId());
            if (a == null || !a.equals(v)) return;

            Team t = teams.get(a);
            if (t != null && !t.friendlyFire) {
                e.setCancelled(true);
                attacker.sendMessage(T_PREFIX + "§cFriendly fire is off for your team.");
            }
        }

        // ---------- Tab completion ----------

        @Override
        public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command cmd,
                                          @NotNull String alias, @NotNull String[] args) {
            if (!(sender instanceof Player p) || !cmd.getName().equalsIgnoreCase("team")) return List.of();
            List<String> out = new ArrayList<>();

            if (args.length == 1) {
                for (String sub : SUBS) if (sub.startsWith(args[0].toLowerCase())) out.add(sub);
                return out;
            }
            if (args.length != 2) return out;

            String sub = args[0].toLowerCase();
            String prefix = args[1].toLowerCase();
            Team mine = teamOf(p);

            switch (sub) {
                case "invite" -> {
                    for (Player o : Bukkit.getOnlinePlayers()) {
                        if (!o.equals(p) && !byPlayer.containsKey(o.getUniqueId())
                                && o.getName().toLowerCase().startsWith(prefix)) out.add(o.getName());
                    }
                }
                case "kick", "transfer" -> {
                    if (mine != null) {
                        for (UUID id : mine.members) {
                            String n = nameOf(id);
                            if (!id.equals(p.getUniqueId()) && n.toLowerCase().startsWith(prefix)) out.add(n);
                        }
                    }
                }
                case "accept", "deny" -> {
                    for (String key : validInvites(p.getUniqueId())) {
                        Team t = teams.get(key);
                        if (t != null && key.startsWith(prefix)) out.add(t.name);
                    }
                }
                case "info" -> {
                    for (Team t : teams.values()) if (t.name.toLowerCase().startsWith(prefix)) out.add(t.name);
                }
                default -> { }
            }
            return out;
        }
    }
}
